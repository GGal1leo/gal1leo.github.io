from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
import os
import time
import matplotlib.pyplot as plt


def split_message(message, chunk_size):
    """Split message into chunks"""
    return [message[i:i+chunk_size] for i in range(0, len(message), chunk_size)]


def encrypt_message(public_key, message, chunk_size):
    encrypted_chunks = []
    for chunk in split_message(message, chunk_size):
        encrypted_chunks.append(public_key.encrypt(
            chunk,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None)
        ))
    return encrypted_chunks


def decrypt_message(private_key, encrypted_chunks):
    decrypted_chunks = []
    for chunk in encrypted_chunks:
        decrypted_chunks.append(private_key.decrypt(
            chunk,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None)
        ))
    return b"".join(decrypted_chunks)

key_sizes = [2048, 3072, 4096, 7680, 15360]
enc_averges, dec_averages = [], []
for key in key_sizes:
    enc_times, dec_times = [], []
    # Generate a private key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=key,
    )

    public_key = private_key.public_key()

    long_plaintext = os.urandom(4096)
    for i in range(10):
        enc_start = time.perf_counter()
        long_cipher = encrypt_message(public_key, long_plaintext, 128)
        enc_end = time.perf_counter()
        dec_start = time.perf_counter()
        long_plaintext_2 = decrypt_message(private_key, long_cipher)
        dec_end = time.perf_counter()
        enc_times.append(enc_end - enc_start)
        dec_times.append(dec_end - dec_start)
    enc_averges.append(sum(enc_times)/len(enc_times))
    dec_averages.append(sum(dec_times)/len(dec_times))

    # print("Key Size: ", key)
    # print("Encryption Time: ", enc_end - enc_start)
    # print("Decryption Time: ", dec_end - dec_start)

print("Encryption Averages: ", enc_averges)
print("Decryption Averages: ", dec_averages)

plt.plot(key_sizes, enc_averges, label="Encryption", marker="o")
plt.plot(key_sizes, dec_averages, label="Decryption", marker="o")
plt.xlabel("Key Size")
plt.ylabel("Time (s)")
plt.legend()
plt.show()
