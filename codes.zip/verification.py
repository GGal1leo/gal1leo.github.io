from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, dsa, ec, padding
import os
import time
import matplotlib.pyplot as plt

key_sizes = [1024, 2048, 3072, 4096]
ec_sizes = [ec.SECP192R1(), ec.SECP256R1(), ec.SECP384R1, ec.SECP521R1()]
rsa_avg, dsa_avg, ec_avg = [], [], []

for size in key_sizes:
    # Generate a private key only once to save my cpu from going insane
    ec_values, rsa_values, dsa_values = [], [], []
    private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=size,
        )
    public_key = private_key.public_key()
    message = os.urandom(4096)
    message_hash = hashes.Hash(hashes.SHA256())
    message_hash.update(message)
    message_digest = message_hash.finalize()
    signature = private_key.sign(
            message_digest,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
    )
    for i in range(1000):
        start = time.perf_counter()
        public_key.verify(
            signature,
            message_digest,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )

        end = time.perf_counter()
        rsa_values.append(end - start)
    
    # Generate a private key only once to save my cpu from going insane
    private_key = dsa.generate_private_key(
        key_size=size
    )
    public_key = private_key.public_key()
    message = os.urandom(4096)
    message_hash = hashes.Hash(hashes.SHA256())
    message_hash.update(message)
    message_digest = message_hash.finalize()
    signature = private_key.sign(
            message_digest,
            hashes.SHA256()
    )
    for i in range(1000):
        start = time.perf_counter()
        public_key.verify(
            signature,
            message_digest,
            hashes.SHA256()
        )
        end = time.perf_counter()
        dsa_values.append(end - start)
    rsa_avg.append(sum(rsa_values) / len(rsa_values))
    dsa_avg.append(sum(dsa_values) / len(dsa_values))

for size in ec_sizes:
        private_key = ec.generate_private_key(
            curve=size
        )
        public_key = private_key.public_key()
        message = os.urandom(4096)
        message_hash = hashes.Hash(hashes.SHA256())
        message_hash.update(message)
        message_digest = message_hash.finalize()
        signature = private_key.sign(
                message_digest,
                ec.ECDSA(hashes.SHA256())
        )
        for i in range(1000):
            start = time.perf_counter()
            public_key.verify(
                signature,
                message_digest,
                ec.ECDSA(hashes.SHA256())
            )
            
            end = time.perf_counter()
            ec_values.append(end - start)
        ec_avg.append(sum(ec_values) / len(ec_values))

print("RSA average time: ", rsa_avg)
print("DSA average time: ", dsa_avg)
print("EC average time: ", ec_avg)

bit_security = [128, 192, 224, 256]
for i in range(len(bit_security)):
    print("Bit Security: ", bit_security[i])
    print("RSA: ", rsa_avg[i])
    print("DSA: ", dsa_avg[i])
    print("EC: ", ec_avg[i])

plt.plot(bit_security, rsa_avg, label="RSA", marker="o")
plt.plot(bit_security, dsa_avg, label="DSA", marker="o")
plt.plot(bit_security, ec_avg, label="EC", marker="o")
plt.xlabel("Bit Security")
plt.ylabel("Time")
plt.legend()
plt.show()


