from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa, dsa,ec
import time
import tqdm
import matplotlib.pyplot as plt
# import threading

# 128, 192, 224, 256
key_sizes = [1024, 2048, 3072, 4096]
ec_sizes = [ec.SECP192R1(), ec.SECP224R1(), ec.SECP256R1(), ec.SECP521R1()]

rsa_times,rsa_avg = [],[]
dsa_times,dsa_avg = [],[]
ec_times,ec_avg = [],[]

for size in key_sizes:
    for i in tqdm.tqdm(range(30)):
        start = time.perf_counter()
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=size,
        )
        end = time.perf_counter()
        rsa_times.append(end-start)
    rsa_avg.append(sum(rsa_times)/len(rsa_times))
    for i in tqdm.tqdm(range(10)):
        start = time.perf_counter()
        private_key = dsa.generate_private_key(
            key_size=size
        )
        end = time.perf_counter()
        dsa_times.append(end-start)
    dsa_avg.append(sum(dsa_times)/len(dsa_times))
    rsa_times.clear()
    dsa_times.clear()

for size in ec_sizes:
    for i in tqdm.tqdm(range(1000)):
        start = time.perf_counter()
        private_key = ec.generate_private_key(
            curve=size
        )
        end = time.perf_counter()
        ec_times.append(end-start)
    ec_avg.append(sum(ec_times)/len(ec_times))
    ec_times.clear()

print("RSA average time: ", rsa_avg)
print("DSA average time: ", dsa_avg)
print("EC average time: ", ec_avg)

bit_security = [128, 192, 224, 256]
for i in range(len(bit_security)):
    print("Bit Security: ", bit_security[i])
    print("RSA: ", rsa_avg[i])
    print("DSA: ", dsa_avg[i])
    print("EC: ", ec_avg[i])

plt.plot(bit_security, rsa_avg, label="RSA", marker="o")
plt.plot(bit_security, dsa_avg, label="DSA", marker="o")
plt.plot(bit_security, ec_avg, label="EC", marker="o")
plt.xlabel("Bit Security")
plt.ylabel("Time (s)")
plt.legend()
plt.show()
